﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour
{
    public float speed;
    public float lineOfSite;
    public float shootingRange;
    public float fireRate;
    public GameObject bulletPrefab;
    public bool MoveRight;
    public float hitPoints;
    public GameObject Rgun;
    public GameObject Lgun;
    public float maxBorder;

    private GameObject bala;
    private GameObject player;
    private Vector2 CurrentPos;
    private float nextFireTime;
    private SpriteRenderer sprite;
    private bool rotation;
    private float waitedTime;
    private float timeToSpin = 1000;
    private bool Stay;
    private Animator animator;
    private Rigidbody2D rb2d;

    enum typeStances { passive, follow, attack }
    typeStances stances = typeStances.passive;
    void Start()
    {
        player = GameObject.FindWithTag("Player");
        sprite = GetComponent<SpriteRenderer>();
        animator = GetComponent<Animator>();
        rb2d = GetComponent<Rigidbody2D>();
        nextFireTime = 0;
        CurrentPos = transform.position;
        rotation = true;
        Stay = false;
    }

    private void FixedUpdate()
    {


        float distanceFromPlayer = Vector2.Distance(player.transform.position, transform.position);

        float delta = Time.deltaTime * 1000;
        nextFireTime += delta;

        if (hitPoints <= 0)
        {
           gameObject.SetActive(false);
        }

        switch (stances)
        {
            case typeStances.passive:

                if (Stay)
                {
                    waitedTime += delta;
                    animator.SetBool("Moving", false);
                    rb2d.velocity = new Vector2(0,0);
                    if (waitedTime > timeToSpin){
                        waitedTime = 0;
                        Stay = false;
                    }

                }
                else
                {
                    animator.SetBool("Moving", true);
                    if (transform.position.x > CurrentPos.x + maxBorder && MoveRight)
                    {
                        MoveRight = false;
                        Stay = true;

                    }
                    if (transform.position.x < CurrentPos.x - maxBorder && !MoveRight)
                    {
                        MoveRight = true;
                        Stay = true;
                    }

                    if (MoveRight)
                    {

                        rb2d.AddForce(new Vector2(speed,0));
                        if (!rotation)
                        {
                            sprite.flipX = false;
                            rotation = true;

                        }
                    }
                    else
                    {
                        rb2d.AddForce(new Vector2(-speed, 0));
                        if (rotation)
                        {
                            sprite.flipX = true;
                            rotation = false;

                        }
                    }
                }

                if (distanceFromPlayer < lineOfSite)
                {
                    stances = typeStances.follow;
                }
                

                break;


            case typeStances.follow:
                animator.SetBool("Moving", true);
                if (player.transform.position.x > transform.position.x)
                {
                    
                    MoveRight = true;
                }
                else if (player.transform.position.x < transform.position.x)
                {
                    
                    MoveRight = false;
                }

                if (MoveRight)
                {
                    rb2d.AddForce(new Vector2(speed, 0));

                    if (!rotation)
                    {
                        sprite.flipX = false;
                        rotation = true;

                    }
                }
                else
                {
                    rb2d.AddForce(new Vector2(-speed, 0));
                    if (rotation)
                    {
                        sprite.flipX = true;
                        rotation = false;

                    }
                }

                if (distanceFromPlayer > lineOfSite)
                {
                    stances = typeStances.passive;
                }
                if (distanceFromPlayer <= shootingRange)
                {
                    stances = typeStances.attack;
                    rb2d.velocity = new Vector2(0, 0);
                }

                break;

            case typeStances.attack:
                animator.SetBool("Moving", false);
                if (player.transform.position.x > transform.position.x)
                {

                    if (!rotation)
                    {
                        sprite.flipX = false;
                        rotation = true;
                    
                    }
                }
                else if (player.transform.position.x < transform.position.x)
                {
                    if (rotation)
                    {
                        sprite.flipX = true;
                        rotation = false;

                    }

                    
                }

                checkIfTimeToFire();
                if (distanceFromPlayer > shootingRange)
                {
                    stances = typeStances.follow;
                }

                break;



        }



    }

    void OnTriggerEnter2D(Collider2D collider)
    {
        if (collider.gameObject.tag == "Bullets")
        {
            TakeHit();
        }

    }
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.green;
        Gizmos.DrawWireSphere(transform.position, lineOfSite);
        Gizmos.DrawWireSphere(transform.position, shootingRange);

    }
    void checkIfTimeToFire()
    {

        if (nextFireTime > fireRate)
        {
            if (sprite.flipX == true)
            {
                bala = Instantiate(bulletPrefab, Lgun.transform.position, Lgun.transform.rotation);
            }
            else
            {
                bala = Instantiate(bulletPrefab, Rgun.transform.position, Rgun.transform.rotation);
            }
            
            Destroy(bala, 2);
            nextFireTime = 0;
        }
    }
    public void TakeHit()
    {

        hitPoints--;
    }
}
