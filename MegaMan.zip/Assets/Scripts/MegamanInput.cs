﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MegamanInput : MonoBehaviour
{
    public static float Vertical
    {
        get { return Input.GetAxisRaw("Vertical"); }
    }
   
    public static float Horizontal
    {
        get { return Input.GetAxisRaw("Horizontal"); }
    }


    public static bool CrouchDown
    {
        get { return Input.GetKeyDown(KeyCode.S); }
    }

    public static bool CrouchUp
    {
        get { return Input.GetKeyUp(KeyCode.S); }
    }

    public static bool Jump
    {
        get { return Input.GetKeyDown(KeyCode.Space); }
    }

    public static bool Shoot
    {
        get { return Input.GetMouseButton(0); }

    }

    public static bool Menu
    {
        get { return Input.GetKey(KeyCode.Escape); }

    }
}
