﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bulletController : MonoBehaviour
{
    public float speed;

    private Animator animator;
    private bool hit = false;
    private float destroyTimer;
    private float animationDuration = 200f;


    // Start is called before the first frame update
    void Start()
    {
        animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        float delta = Time.deltaTime * 1000;
        transform.position += transform.up * speed * Time.deltaTime;

        if (hit)
        {

            destroyTimer += delta;
            if (destroyTimer > animationDuration)
            {
                Destroy(gameObject);
            }
        }

    }


    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Map" )
        {
            /*Vector3 pos = transform.position * 0 + transform.position;
            Destroy(gameObject);
            bulletHit = Instantiate(bulletPrefab, pos, transform.rotation);*/
            gameObject.tag = "Untagged";
            speed = 0;
            hit = true;
            animator.SetTrigger("HIT");
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        /*Vector3 pos = transform.position * 0 + transform.position;
        Destroy(gameObject);
        bulletHit = Instantiate(bulletPrefab, pos, transform.rotation);*/
        if (collision.gameObject.tag == "Scenari"){
            speed = 0;
            hit = true;
            animator.SetTrigger("HIT");
        }

        if (collision.gameObject.tag == "Enemy"){
            speed = 0;
            hit = true;
            animator.SetTrigger("HIT");
        }
    }



}
