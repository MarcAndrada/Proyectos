﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MegamanController : MonoBehaviour
{
    
    public float runSpeed;
    public float MaxSpeed;
    public Vector2 jumpHeight;
    public GameObject Rgun;
    public GameObject Lgun;
    public float fireRate;
    public GameObject bulletPrefab;
    public float hitPoints;
    public GameObject DieText;
    public GameObject Corazon1;
    public GameObject Corazon2;
    public GameObject Corazon3;


    private Animator animator;
    private Rigidbody2D rb2d;
    private SpriteRenderer sprite;
    private BoxCollider2D box2d;
    private bool shoot;
    private bool jump;
    private float run;
    private int jumpCount;
    private bool canJump;
    private bool onAir;
    private float currentRunSpeed;
    private float nextFireTime;
    private GameObject bala;

    // Start is called before the first frame update
    void Start()
    {
        animator = GetComponent<Animator>();
        rb2d = GetComponent<Rigidbody2D>();
        sprite = GetComponent<SpriteRenderer>();
        box2d = GetComponent<BoxCollider2D>();
        canJump = true;
        jumpCount = 0;
        currentRunSpeed = runSpeed;
    }

    // Update is called once per frame
    void Update()
    {

        float delta = Time.deltaTime * 1000;
        nextFireTime += delta;

        run = MegamanInput.Horizontal;
        shoot = MegamanInput.Shoot;
        jump = MegamanInput.Jump;

        if (hitPoints <= 0)
        {
            gameObject.SetActive(false);
            DieText.SetActive(true);
        }

        if (jump && canJump)
        {
            if (jumpCount >= 1)
            {
                rb2d.velocity = new Vector2(rb2d.velocity.x, 0);
            }
            rb2d.AddForce(Vector2.up * jumpHeight, ForceMode2D.Impulse);

            jumpCount++;
            if (jumpCount >= 2){
                canJump = false;
            }
        }

        if (run == 1 || run == -1)
        {
            animator.SetBool("Running", true);
        }
        else if (run == 0){
            animator.SetBool("Running", false);

        }


        if (shoot)
        {
            animator.SetBool("Shooting", true);
            checkIfTimeToFire();
        }
        else{
            animator.SetBool("Shooting", false);

        }
    }

    private void FixedUpdate()
    {

        if (run == 1 && sprite.flipX)
        {

            sprite.flipX = false;
        }
        
        if (run == -1 && !sprite.flipX)
        {
            sprite.flipX = true;
        }

        rb2d.AddForce(Vector2.right * runSpeed * run);

        if (MaxSpeed < rb2d.velocity.x)
        {
            rb2d.velocity = new Vector2 (MaxSpeed, rb2d.velocity.y);
        }
        
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Scenari")
        {
            if (onAir)
            {
                bool col1 = false;
                bool col2 = false;
                bool col3 = false;
                float center_x = (box2d.bounds.min.x + box2d.bounds.max.x) / 2;
                Vector2 centerPosition = new Vector2(center_x, box2d.bounds.min.y);
                Vector2 leftPosition = new Vector2(center_x, box2d.bounds.min.y);
                Vector2 RightPosition = new Vector2(center_x, box2d.bounds.min.y);
                
                RaycastHit2D[] hits = Physics2D.RaycastAll(centerPosition, -Vector2.up, 250);
                if (checkRaycastWithScenario(hits)){ col1 = true; }

                hits = Physics2D.RaycastAll(leftPosition, -Vector2.up, 250);
                if (checkRaycastWithScenario(hits)) { col2 = true; }
                
                hits = Physics2D.RaycastAll(RightPosition, -Vector2.up, 250);
                if (checkRaycastWithScenario(hits)) { col3 = true; }

                if (col1 || col2 || col3){
                    animator.SetBool("Jumping", false);
                    canJump = true;
                    jumpCount = 0;
                    onAir = false;
                    runSpeed = currentRunSpeed;
                    rb2d.drag = 2;

                }
            }
            
        }
    }

    private void OnCollisionExit2D(Collision2D collision){
        if (collision.gameObject.tag == "Scenari")
        {
            rb2d.drag = 0;
            runSpeed = 200;
            onAir = true;
            animator.SetBool("Jumping", true);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "EnemyBullets")
        {
            TakeHit();
        }

        if (collision.gameObject.tag == "Teleport")
        {
            SceneManager.LoadScene("LoadingScreen");
        }
    }


    private bool checkRaycastWithScenario(RaycastHit2D[] hits)
    {
        foreach(RaycastHit2D hit in hits)
        {
            if (hit.collider != null) {
                if (hit.collider.gameObject.tag == "Scenari")
                {
                    return true;
                }
            }
        }
        return false;
    }

    private void checkIfTimeToFire()
    {

        if (nextFireTime > fireRate)
        {
            if (sprite.flipX == true)
            {
                bala = Instantiate(bulletPrefab, Lgun.transform.position, Lgun.transform.rotation);
            }
            else
            {
                bala = Instantiate(bulletPrefab, Rgun.transform.position, Rgun.transform.rotation);
            }

            Destroy(bala, 2);
            nextFireTime = 0;
        }
    }
    public void TakeHit()
    {
        hitPoints--;
        if (hitPoints == 3)
        {
            Corazon3.SetActive(true);
            Corazon2.SetActive(true);
            Corazon1.SetActive(true);
        }
        else if (hitPoints == 2)
        {
            Corazon3.SetActive(false);
            Corazon2.SetActive(true);
            Corazon1.SetActive(true);
        }
        else if (hitPoints == 1)
        {
            Corazon3.SetActive(false);
            Corazon2.SetActive(false);
            Corazon1.SetActive(true);
        }
        else
        {
            Corazon3.SetActive(false);
            Corazon2.SetActive(false);
            Corazon1.SetActive(false);
        }

    }

}
