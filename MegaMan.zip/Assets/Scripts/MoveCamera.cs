﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MoveCamera : MonoBehaviour
{

    public GameObject Player;
    public Vector2 minCamPos;
    public Vector2 maxCamPos;

    void FixedUpdate(){
            float posX = Player.transform.position.x;
            float posY = Player.transform.position.y;

            transform.position =
                new Vector3(
                    Mathf.Clamp(posX, minCamPos.x, maxCamPos.x),
                    Mathf.Clamp(posY, minCamPos.y, maxCamPos.y),
                    transform.position.z);

    }


    public void SetMaxCamX(float MaxX)
    {
        maxCamPos.x = MaxX;
    }
    public void SetMaxCamY(float MaxY)
    {
        maxCamPos.y = MaxY;
    }
    public void SetMinCamX(float MinX)
    {
        minCamPos.x = MinX;
    }
    public void SetMinCamY(float MinY)
    {
        minCamPos.y = MinY;
    }


}



